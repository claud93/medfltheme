








<?php
/**
 * Шаблон подвала (footer.php)
 * @package WordPress
 * @subpackage your-clean-template-3
 */
?>

<?php wp_footer(); // необходимо для работы плагинов и функционала  ?>

    <?php
if( wp_is_mobile() ) {
include "footer-mobile.php";
}else{
include "footer-desktop.php";
}
 ?>
</body>
</html>