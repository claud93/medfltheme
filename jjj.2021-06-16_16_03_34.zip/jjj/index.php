
<?php
/**
 * Главная страница (index.php)
 * @package WordPress
 * @subpackage your-clean-template-3
 */
get_header(); // подключаем header.php ?> 
<?php
if( wp_is_mobile() ) {
include "index-mobile.php";
}else{
include "index-desktop.php";
}
 ?>


<?php get_footer(); // подключаем footer.php ?>