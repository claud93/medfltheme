<?php
/**
 * Шаблон шапки (header.php)
 * @package WordPress
 * @subpackage Hospital
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); // вывод атрибутов языка ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); // кодировка ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0>



	<!--[if lt IE 9]>
	<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<?php wp_head(); // необходимо для работы плагинов и функционала ?>
    <div class="aa">
    <img onclick="mqu()" class="mmi" src="<?php echo get_template_directory_uri(); ?>/img/menu.svg"/>
    <img height="100%" src="<?php echo get_template_directory_uri(); ?>/img/logo.svg"/>


<div onclick="mquq()" class="mmt"><a href="#contact">
 try it now</a>
</div>

    </div>
   
    <div onclick="mquq()" id="mpop" class="aam">
    <img class="x" src="<?php echo get_template_directory_uri(); ?>/img/close1.png"/>
 <img class="mmtt" src="<?php echo get_template_directory_uri(); ?>/img/gery.png"/>
<?php wp_nav_menu(); ?>
<div class="ad">
<a href="#contact">
Apply for Demo
</a>
</div>


</div>