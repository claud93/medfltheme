function setInputFilter(textbox, inputFilter) {
  ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
    textbox.addEventListener(event, function() {
      if (inputFilter(this.value)) {
        this.oldValue = this.value;
        this.oldSelectionStart = this.selectionStart;
        this.oldSelectionEnd = this.selectionEnd;
      } else if (this.hasOwnProperty("oldValue")) {
        this.value = this.oldValue;
        this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
      } else {
        this.value = "";
      }
    });
  });
}

setInputFilter(document.getElementById("number"), function(value) {
  return /^-?\d*$/.test(value); });
setInputFilter(document.getElementById("name"), function(value) {
  return /^[a-z]*$/i.test(value); });


var getCookie = function(name) {
	var getCookieValues = function(cookie) {
		var cookieArray = cookie.split('=');
		return cookieArray[1].trim();
	};

	var getCookieNames = function(cookie) {
		var cookieArray = cookie.split('=');
		return cookieArray[0].trim();
	};

	var cookies = document.cookie.split(';');
	var cookieValue = cookies.map(getCookieValues)[cookies.map(getCookieNames).indexOf(name)];

	return (cookieValue === undefined) ? null : cookieValue;
    
};




function de() {

document.getElementById("de").style.color = "black";
document.getElementById("de").style.fontFamily = "Manropeb";
document.getElementById("en").style.color = "gray";
document.getElementById("en").style.fontFamily = "Manrope";
document.cookie = "lang=de"; 
document.getElementById("zag").innerHTML = "Optimieren Sie Ihr Krankenhaus um die Produktivität</br> zu erhöhen.";
document.getElementById("zag").style.width = "805px";
document.getElementById("ve").style.margin = "-9px 434px 0 0";

document.getElementById("imd").style.display = "block";
document.getElementById("ime").style.display = "none";

document.getElementById("menu-item-430").innerHTML = "<a href='#about'>Über</a>";
document.getElementById("menu-item-432").innerHTML = "<a href='#stats'>Wie es funktionert</a>";
document.getElementById("menu-item-433").innerHTML = "<a href='#how'>Statistiken</a>";
document.getElementById("menu-item-434").innerHTML = "<a href='#contact'>Kontakt</a>";

document.getElementById("ti").innerHTML = "<a href='/#contact'>Jetzt ausprobieren</a>";
document.getElementById("ap").innerHTML = "<a href='/#contact'>Kostenlose Demo anfordern</a>";
document.getElementById("ap").style.width = "336px";

document.getElementById("za22").innerHTML = "Über MedFLux";

document.getElementById("tx").innerHTML = "<p>Üblicherweise finden in Krankenhäusern Termine mit Ärzt*innen und Geräten statt, ohne die Produktivität und Auslastung einzubeziehen. Das Krankenhauspersonal registriert die Patient*innen, ohne diese beiden Faktoren zu wissen. Dadurch entstehen lange Schlangen mit Wartezeiten von bis zu mehreren Stunden.</p></br><p>Unser intelligentes System weist alle Patient*innen zu den Behandlungsstationen zu. Dies wird in Echtzeit anhand von Algorithmen realisiert. Dadurch wird die Arbeit des Krankenhauspersonals vereinfacht und es sparen nicht nur die Patient*innen Zeit, sondern auch das gesamte Personal. MedFlux kann in der Notaufnahme, einzelnen Stationen und Ambulanzen eingesetzt werden.</p>";

document.getElementById("ft1").innerHTML = "Freie Stationen";
document.getElementById("ft2").innerHTML = "Bestätigung in der App";
document.getElementById("ft3").innerHTML = "Produktivität";

document.getElementById("ftt1").innerHTML = " Nach der Registrierung erhalten die Patient*innen eine Identifikationsnummer. Das System sucht nach einer Behandlungsstation, abhängig davon, welche Spezialisierung die Patient*innen benötigen.";
document.getElementById("ftt2").innerHTML = "Im Anschluss bestätigen Patient*innen den Besuch bei der Behandlungsstation, welche gerade frei ist. Dadurch wird Zeit eingespart.";
document.getElementById("ftt3").innerHTML = "Die Krankenhausinhaberin erhält Statistiken über die Arbeit der Ärzt*innen und Geräte. Die Effizienz der Klinik wird signifikant gesteigert.";

document.getElementById("ttz1").innerHTML = "Web";
document.getElementById("ttz2").innerHTML = "Mobil";
document.getElementById("ttz3").innerHTML = "Patientenzufriedenheit";
document.getElementById("ttz4").innerHTML = "Entlastung des Personals";
document.getElementById("ttz5").innerHTML = "Kommunikation";
document.getElementById("ttz6").innerHTML = "Metadaten-Analyse/Algorithmus";

document.getElementById("ttz11").innerHTML = "Praktische Web Anwendung, um die Zusammenarbeit zwischen Mitarbeiter*innen und Patient*innen zu optimieren. Das Personal checkt die Patient*innen in der Web Anwendung ein und kann die Behandlungsstationen mitverfolgen.";
document.getElementById("ttz22").innerHTML = "Patient*innen bestätigen Termine mit einem Klick in der mobilen App. Somit können Sie an jedem Ort erreicht werden und wissen zu jeder Zeit, wohin Sie gehen müssen.";
document.getElementById("ttz33").innerHTML = "Durch verringerte Wartezeiten und bessere Abläufe wird die Zufriedenheit der Patient*innen gesteigert. Das Personal hat mehr Zeit sich um ihre Anliegen zu kümmern, statt Prozesse zu managen.";
document.getElementById("ttz44").innerHTML = "Das Personal wird durch reibungslose Abläufe entlastet und kann mehr Zeit für Patient*innen aufwenden. Das Koordiniern des Patientenflusses wird komplett von MedFlux übernommen.";
document.getElementById("ttz55").innerHTML = "Mitarbeiter*innen können über den eingebauten Chat miteinander kommunizieren. Durch eine Vernetzung aller Behandlungsräume wird die Kommunikation im Krankenhaus optimiert.";
document.getElementById("ttz66").innerHTML = "</br>MedFlux optimiert in Echtzeit anhand von Algorithmen die Auslastung aller Behandlungsstationen. Das System wird mit vorhandenen Metadaten trainiert und weist alle Patient*innen zu der bestmöglichen Behandlungsstation zu. ";

document.getElementById("ai").innerHTML = "Patientenfluss-Management für Krankenhäuser";
document.getElementById("ai").style.width = "470px";

document.getElementById("at").innerHTML = "Zeit ist die wertvollste Ressource, die sie beim Betreiben eines Krankenhauses haben. Sparen Sie die Zeit zum Managen des Patientenflusses.";

document.getElementById("ab").innerHTML = "Kostenlose Demo anfordern ";
document.getElementById("ab").style.width = "299px";

document.getElementById("cos").innerHTML = "DSGVO";
document.getElementById("coz").innerHTML = "Hergestellt in Deutschland";

document.getElementById("cot").innerHTML = "-MedFlux wird in Deutschland entwickelt</br>- Die von Medflux erhobenen Informationen dienen nur für die Zuweisung zu den Behandlungsstationen</br>- Darüber hinaus werden keine Patientendaten erhoben</br>- MedFlux enstpricht allen Anforderungen der DSGVO";

document.getElementById("soz").innerHTML = "Mobile App für Patientinnen";

document.getElementById("sot").innerHTML = "Patientinnen sehen in der App, in welches Behandlungszimmer sie gehen müssen. Somit werden Patientinnen zu jedem Zeitpunkt an jedem Ort erreicht und es wird ein reibungsloser Ablauf ermöglicht. Durch das Echtzeit-Management ist der/die Patientin immer informiert und das Behandlungszimmer steht nie leer. ";

document.getElementById("flz").innerHTML = "Kontaktieren Sie uns!";

document.getElementById("pn").innerHTML = "Telefonnummer";

document.getElementById("aply").innerHTML = "Kostenlose Demo anfordern";


document.getElementById("checkb").innerHTML = "Ich stimme der Verarbeitung meiner</br> personenbezogenen Daten zu";

document.getElementById("nam").innerHTML = "<input class='inp' id='name' placeholder='Bitte geben Sie Ihren Vor- Und Zunamen ein' type='text' size='40'>";

document.getElementById("num").innerHTML = "<input class='inp' id='number' placeholder='Bitte gib deine Telefonnummer ein' type='text' size='40'>";

document.getElementById("ema").innerHTML = "<input class='inp' id='mail' placeholder='Bitte geben Sie Ihre E-Mail Adresse ein' type='text' size='40'>";

document.getElementById("ema2").innerHTML = "<input class='inp' id='mail' placeholder='Bitte geben Sie Ihre E-Mail Adresse ein' type='text' size='40'>";

document.getElementById("fo1").innerHTML = "Die effizienteste Lösung um die Produktivität Ihres Krankenhauses zu verbessern und Patientinnen einen stressfreien Krankenhausaufenthalt zu ermöglichen";

document.getElementById("fo2").innerHTML = "Haben Sie Fragen?";


document.getElementById("fo4").innerHTML = "Über";

document.getElementById("fo5").innerHTML = "Kontaktieren Sie uns gern per</br>Telefon oder E-Mail";

document.getElementById("pop1").innerHTML = "Haben Sie Fragen?";
document.getElementById("pop2").innerHTML = "Schicken Sie uns eine Nachricht und wir beantworten diese schnellstmöglich";

document.getElementById("pop4").innerHTML = "Ihre Nachricht";

document.getElementById("pop5").innerHTML = " <textarea class='inp' id='mess' placeholder='Ihre Nachricht' type='comment' cols='40' rows='3'></textarea>";

document.getElementById("pop6").innerHTML = "Senden";
}









function en() {
document.getElementById("en").style.color = "black";
document.getElementById("en").style.fontFamily = "Manropeb";
document.getElementById("de").style.color = "gray";
document.getElementById("de").style.fontFamily = "Manrope";
document.cookie = "lang=en"; 
document.getElementById("zag").innerHTML = "MedFlux is a system for queues optimization. </br>It’s intelligent medical web assistant.";
document.getElementById("zag").style.width = null;

document.getElementById("imd").style.display = "none";
document.getElementById("ime").style.display = "block";
document.getElementById("ve").style.margin = "-9px 90px 0 0";


document.getElementById("menu-item-430").innerHTML = "<a href='#about'>About</a>";
document.getElementById("menu-item-432").innerHTML = "<a href='#stats'>stats</a>";
document.getElementById("menu-item-433").innerHTML = "<a href='#how'>Mobil</a>";
document.getElementById("menu-item-434").innerHTML = "<a href='#contakt'>Contact</a>";

document.getElementById("ti").innerHTML = "<a href='/#contact'>Try it now</a>";
document.getElementById("ap").innerHTML = "<a href='/#contact'>Apply for Demo</a>";
document.getElementById("ap").style.width = "226px";

document.getElementById("za22").innerHTML = "About MedFLux";

document.getElementById("tx").innerHTML = "Usually, an appointment with a doctor takes place without taking into account the productivity and workload of the doctor. The medical registrar records the patient without knowing these 2 factors.As a result, long queues of patients are formed, which wait hours for a doctor's appointment.<br><p>Our smart system simplifies the work of a medical registrar and saves time not only for patients, but also for doctors and owner of hospital.</p>";

document.getElementById("ft1").innerHTML = "Free Doctors";
document.getElementById("ft2").innerHTML = "In-app confirmation";
document.getElementById("ft3").innerHTML = "Productivity control";

document.getElementById("ftt1").innerHTML = "The system itself searches for a doctor, depending on what specialization the patient needs. Upon registration, the patient receives his identification number.";
document.getElementById("ftt2").innerHTML = "After receiving an individual number, the patient enters it in the application and confirms his visit to the doctor who is free now, thereby saving time.";
document.getElementById("ftt3").innerHTML = "The hospital owner receives statistics on the work of doctors, the time spent on patients and increases the efficiency of the entire clinic by up to 46,3%";

document.getElementById("ttz1").innerHTML = "Web Application";
document.getElementById("ttz2").innerHTML = "Mobile Application";
document.getElementById("ttz3").innerHTML = "Self-learning";
document.getElementById("ttz4").innerHTML = "Employee efficiency";
document.getElementById("ttz5").innerHTML = "Communication";
document.getElementById("ttz6").innerHTML = "Metadata analysis";

document.getElementById("ttz11").innerHTML = "Praktische Web Anwendung, um die Zusammenarbeit zwischen Mitarbeiter*innen und Patient*innen zu optimieren. Das Personal checkt die Patient*innen in der Web Anwendung ein und kann die Behandlungsstationen mitverfolgen.";
document.getElementById("ttz22").innerHTML = "Patient*innen bestätigen Termine mit Ärzt*innen mit einem Klick in der mobilen App...";
document.getElementById("ttz33").innerHTML = "Durch verringerte Wartezeiten und bessere Abläufe wird die Zufriedenheit der Patient*innen gesteigert...";
document.getElementById("ttz44").innerHTML = "Das Personal wird durch reibungslose Abläufe entlastet und kann mehr Zeit für Patient*innen aufwenden...";
document.getElementById("ttz55").innerHTML = "Mitarbeiter*innen können über den eingebauten Chat miteinandern kommunizieren...";
document.getElementById("ttz66").innerHTML = "</br>MedFlux optimiert in Echtzeit anhand von Algorithmen die Auslastung aller...";

document.getElementById("ai").innerHTML = "All-in-one platform for hospitals";
document.getElementById("ai").style.width = "null";

document.getElementById("at").innerHTML = "Time is the most precious thing you have in running a hospital. You cannot take time to reflect on the productivity of a medical staff.";

document.getElementById("ab").innerHTML = "Get Started for Free";
document.getElementById("ab").style.width = "235px";

document.getElementById("cos").innerHTML = "DSGVO";
document.getElementById("coz").innerHTML = "Made in Germany";

document.getElementById("sot").innerHTML = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et tristique placerat donec sodales dictum gravida fermentum faucibus. Id quis quam tincidunt hendrerit enim eget elit. Phasellus in varius proin aliquet ac turpis amet. Hendrerit nisi, turpis mi viverra. Lectus ultrices ipsum quis nunc, enim consequat. </p><p>Pellentesque porttitor pellentesque auctor sit fames tempor, netus. Faucibus praesent nulla vel nulla. Sit ornare scelerisque viverra at dolor, ac, at diam gravida. Aliquam arcu velit netus odio sapien vel, mattis.";

document.getElementById("soz").innerHTML = "Mobile App for patients";

document.getElementById("sot").innerHTML = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et tristique placerat donec sodales dictum gravida fermentum faucibus. Id quis quam tincidunt hendrerit enim eget elit. Phasellus in varius proin aliquet ac turpis amet. Hendrerit nisi, turpis mi viverra. Lectus ultrices ipsum quis nunc, enim consequat. Pellentesque porttitor pellentesque auctor sit fames tempor, netus. Faucibus praesent nulla vel nulla. Sit ornare scelerisque viverra at dolor, ac, at diam gravida. Aliquam arcu velit netus odio sapien vel, mattis.";

document.getElementById("flz").innerHTML = "Let’s Get in Touch!";

document.getElementById("pn").innerHTML = "Phone number";

document.getElementById("checkb").innerHTML = "I agree to the processing of my data";

document.getElementById("aply").innerHTML = "Apply for Demo";

document.getElementById("nam").innerHTML = "<input class='inp' id='name' placeholder='Please enter your name and surname' type='text' size='40'>";

document.getElementById("num").innerHTML = "<input class='inp' id='number' placeholder='Please enter your phone number' type='text' size='40'>";

document.getElementById("ema").innerHTML = "<input class='inp' id='mail' placeholder='Please enter email address' type='text' size='40'>";

document.getElementById("ema2").innerHTML = "<input class='inp' id='mail' placeholder='Bitte geben Sie Ihre E-Mail Adresse ein' type='text' size='40'>";

document.getElementById("fo1").innerHTML = "Your ulitmate optimization solution to improve quality and productivity of medical staff and have better communications with future patients.";
document.getElementById("fo2").innerHTML = "Have any questions?";
document.getElementById("fo4").innerHTML = "About";

document.getElementById("fo5").innerHTML = "Feel free to get in touch with us</br>via phone or send us a message.";

document.getElementById("pop1").innerHTML = "Have any questions?";

document.getElementById("pop2").innerHTML = "Send us your message and we will try to answer as fast as possible.";

document.getElementById("pop4").innerHTML = "Message";

document.getElementById("pop5").innerHTML = " <textarea class='inp' id='mess' placeholder='Your Message' type='comment' cols='40' rows='3'></textarea>";

document.getElementById("pop6").innerHTML = "Send";
}










var vcheck = 0;
var butch = document.getElementById("check");
function check() {

if(vcheck == 0){
butch.style.opacity = "1";
vcheck = 1;
}
else if(vcheck == 1){
vcheck = 0;
butch.style.opacity = "0";
}



}




function isInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)

    );
}

var page1 = document.querySelector('.page1');
var page2 = document.querySelector('.page2');
var page3 = document.querySelector('.page3');
var page4 = document.querySelector('.page4');
var page5 = document.querySelector('.page5');
var page6 = document.querySelector('.page6');
var page7 = document.querySelector('.page7');
var level = 1;

var tar = document.getElementById("t1");
var m1 = document.getElementById("menu-item-430");
var m2 = document.getElementById("menu-item-431");
var m3 = document.getElementById("menu-item-433");
var m4 = document.getElementById("menu-item-432");
var m5 = document.getElementById("menu-item-480");
var m6 = document.getElementById("menu-item-434");

function feature(cor, cory) {
tar.style.top = 1560 + cory +"px";
tar.style.margin = "0 " + cor +"px 0 0"; 
tar.style.height = "83px";
    tar.style.width = "83px";
level = 0;
}



jQuery(function($){
$(window).scroll(function() {


if (isInViewport(page2) && level != 2)  {
    level = 2;
tar.id = "t2";
    tar.style.top = "0";
    tar.style.opacity = "1";
    tar.style.margin = "0"; 
        tar.style.height = "183px";
    tar.style.width = "183px";
    m1.classList.add("menu-item-current");
    m2.classList.remove("menu-item-current");
    m3.classList.remove("menu-item-current");
    m4.classList.remove("menu-item-current");
    m5.classList.remove("menu-item-current");
    m6.classList.remove("menu-item-current");
} 

if (isInViewport(page3) && level != 3 )  {
    level = 3;
tar.id = "t1";
    tar.style.top = "1560px";
        tar.style.height = "83px";
    tar.style.width = "83px";
    m1.classList.remove("menu-item-current");
    m2.classList.add("menu-item-current");
    m3.classList.remove("menu-item-current");
    m4.classList.remove("menu-item-current");
    m5.classList.remove("menu-item-current");
    m6.classList.remove("menu-item-current");
}
if (isInViewport(page4) && level != 4 )  {
    level = 4;
tar.id = "t1";
    tar.style.top = "2440px";
    tar.style.margin = "0 800px 0 0"; 
            tar.style.height = "183px";
    tar.style.width = "183px";
    m1.classList.remove("menu-item-current");
    m2.classList.remove("menu-item-current");
    m3.classList.add("menu-item-current");
    m4.classList.remove("menu-item-current");
    m5.classList.remove("menu-item-current");
    m6.classList.remove("menu-item-current");
}
if (isInViewport(page5) && level != 5 )  {
    level = 5;
tar.id = "t1";
    tar.style.top = "3500px";
    tar.style.margin = "0 360px 0 0"; 
            tar.style.height = "183px";
    tar.style.width = "183px";
    m1.classList.remove("menu-item-current");
    m2.classList.remove("menu-item-current");
    m3.classList.remove("menu-item-current");
    m4.classList.add("menu-item-current");
    m5.classList.remove("menu-item-current");
    m6.classList.remove("menu-item-current");
}
if (isInViewport(page6) && level != 6 )  {
    level = 6;
tar.id = "t1";
    tar.style.top = "4500px";
    tar.style.margin = "0 100px 0 0"; 
            tar.style.height = "183px";
    tar.style.width = "183px";
    m1.classList.remove("menu-item-current");
    m2.classList.remove("menu-item-current");
    m5.classList.add("menu-item-current");
    m4.classList.remove("menu-item-current");
    m3.classList.remove("menu-item-current");
    m6.classList.remove("menu-item-current");
}
if (isInViewport(page7) && level != 7 )  {
    level = 7;
	tar.id = "t1";
    tar.style.top = "4500px";
    tar.style.margin = "0 100px 0 0"; 
            tar.style.height = "183px";
    tar.style.width = "183px";
    m1.classList.remove("menu-item-current");
    m2.classList.remove("menu-item-current");
    m6.classList.add("menu-item-current");
    m4.classList.remove("menu-item-current");
    m5.classList.remove("menu-item-current");
    m3.classList.remove("menu-item-current");
}
});
});

function qu() {
var pop = document.getElementById("pop");
    pop.style.zIndex = "999999";
    pop.style.opacity = "1"; 
    var popo = document.getElementById("popo");
    popo.style.zIndex = "9999999";
    popo.style.opacity = "1"; 
}
function quq() {
var pop = document.getElementById("pop");
    pop.style.zIndex = "-1";
    pop.style.opacity = "0"; 
   var popo = document.getElementById("popo");
    popo.style.zIndex = "-1";
    popo.style.opacity = "0";  
}