<?php
/**
 * Функции шаблона (function.php)
 * @package WordPress
 * @subpackage your-clean-template-3
 */


register_nav_menus(array(
	'top' => 'Верхнее',  
));




function my_ajax_aply(){
$name = $_POST['name'];
$number = $_POST['number'];
$mail = $_POST['mail'];
$post_data = array(
	'post_title'    => $name,
	'post_status'   => 'publish',
);

$post_id = wp_insert_post(wp_slash($post_data) );

add_post_meta($post_id, 'number', $number , true);
add_post_meta($post_id, 'mail', $mail , true);


  echo $name;
die();
};
add_action( 'wp_ajax_aply', 'my_ajax_aply' );


?>