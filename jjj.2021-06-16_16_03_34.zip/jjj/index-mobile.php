<?php

 	wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/style-mobile.css' );

?>





<div class="bbb">
<div class="aaa">
<div class="c1">
<div class="ab">
<img id="ime" src="https://ods.pp.ua/wp-content/themes/jjj/img/opt.png" class="im">
<p class="mpp">
Medflux is a system</br>
for queues optimization.</br>
</p>
It’s intelligent medical web assistant.
<img class="bv" src="<?php echo get_template_directory_uri(); ?>/img/v.png"/>
</div>
<div class="ac" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/mmd.jpg);">
</div>
<div class="ad">
<a href="#contact">
Apply for Demo
</a>
</div>
</div>
<a id="c2" name="about"></a>

<div class="c2">
<div class="ae">
About iMedflow
</div>
<div class="af">
<p>Usually, an appointment with a doctor takes place without taking into account the productivity and workload of the doctor. The medical registrar records the patient without knowing these 2 factors.</br>
As a result, long queues of patients are formed, which wait hours for a doctor's appointment.</p>

Our smart system simplifies the work of a medical registrar and saves time not only for patients, but also for doctors and owner of hospital.
</div>
</div>
<div class="ae">
<div class="aee"><img src="<?php echo get_template_directory_uri(); ?>/img/i1.png"/></div>
<div class="aet">
<p class="aez">Free Doctors</p>
<p class="aett">
The system itself searches for a doctor, depending on what specialization the patient needs. Upon registration, the patient receives his identification number.
</p>
</div>
</div>

<div class="aeb">
<img src="<?php echo get_template_directory_uri(); ?>/img/ma1.png" />
</div>
</div>

<div class="ae">

<div class="aet">
<p class="aez">In-app confirmation</p>
<p class="aett">
After receiving an individual number, the patient enters it in the application and confirms his visit to the doctor who is free now, thereby saving time.</p>
</div>
<div class="aee"><img src="<?php echo get_template_directory_uri(); ?>/img/e.png"/></div>
</div>

<div class="aeb" style="
    text-align: right;
">
<img src="<?php echo get_template_directory_uri(); ?>/img/ma2.png" />

</div>

<div class="ae">
<div class="aee"><img src="<?php echo get_template_directory_uri(); ?>/img/ch.png"/></div>

<div class="aet">
<p class="aez">Free Doctors</p>
<p class="aett">
The system itself searches for a doctor, depending on what specialization the patient needs. Upon registration, the patient receives his identification number.
</p>
</div>
</div>



<div  class="ss3">
<div  class="wr colp">
<div  class="colu w1">
<div  class="coli">
<img src="<?php echo get_template_directory_uri(); ?>/img/o3.png"/>
</div>
<div class="colut">Notaufnahme</div>

</div>
<div class="colu w2">
<div  class="coli">
<img src="<?php echo get_template_directory_uri(); ?>/img/o1.png"/>
</div>
<div class="colut">Station</div>

</div>
<div  class="colu w3">
<div  class="coli">
<img src="<?php echo get_template_directory_uri(); ?>/img/o2.png"/>
</div>
<div class="colut">Ambulanz</div>

</div>
</div>
</div>
<a name="features"></a>

<div  class="fea">
<div class="za2">
<img class="za2im" src=" <?php echo get_template_directory_uri(); ?>/img/fe.png">
How it works
<img class="za2img" src=" <?php echo get_template_directory_uri(); ?>/img/v2.png">
</div>

<div id="feai" class="feai">

<div id="f1" class="sb" onmouseover="feature(890, 0);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/1.jpg)">
</div>
<div class="sbdh">
<div class="page3"></div>
<div id="ttz1" class="ttz">
Web Application
</div>
<div id="ttz11" class="tt">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in pulvinar luctus gravida diam sed. At egestas faucibus congue varius nisi faucibus ultrices dolor, auctor. Elit suspendisse amet aliquam hendrerit suspendisse aliquam suspendisse. Fusce sagittis, mi euismod tincidunt aliquam.

</div>
<a href="#contact">
<div class="tl">
Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>

<div id="f2" class="sb sm" onmouseover="feature(565, 0);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/2.jpg)">

</div>
<div class="sbdh">
<div id="ttz2" class="ttz">
Mobile Application
</div>
<div id="ttz22" class="tt">
The patient confirms his appointment with the doctor with one click in the mobile application.
</div>
<a href="#contact">
<div class="tl">
Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>

<div id="f3" class="sb" onmouseover="feature(250, 0);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/3.jpg)">

</div>
<div class="sbdh">
<div id="ttz3" class="ttz">
Self-learning
</div>
<div id="ttz33" class="tt">
The system is trained on the basis of available data and accurately assigns patients to free doctors.</div>
<a href="#contact">
<div class="tl">

Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>

<div id="f4" class="sb" onmouseover="feature(890, 370);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/4.jpg)">

</div>
<div class="sbdh">
<div id="ttz4" class="ttz">
Employee efficiency
</div>
<div id="ttz44" class="tt">
The statistics displays the doctors' time spent on patients, and also calculates their productivity.</div>
<a href="#contact">
<div class="tl">
Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>
<div id="f5" class="sb sm" onmouseover="feature(565, 370);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/5.jpg)">

</div>
<div class="sbdh">
<div id="ttz5" class="ttz">
Communication
</div>
<div id="ttz55" class="tt">
A convenient chat is built into the system for communication between medical staff.</div>
<a href="#contact">
<div class="tl">
Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>
<div id="f6" class="sb" onmouseover="feature(250, 370);">

<div class="tim" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/6.jpg)">
</div>
<div class="sbdh">
<div id="ttz6" class="ttz">
Metadata analysis
</div>
<div id="ttz66" class="tt">
A convenient chat is built into the system for communication between medical staff.</div>
<a href="#contact">
<div class="tl">
Get more details<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.4454 1.63368C10.1851 1.37333 10.1851 0.951217 10.4454 0.690868C10.7058 0.430518 11.1279 0.430518 11.3882 0.690868L15.3882 4.69087C15.6486 4.95122 15.6486 5.37333 15.3882 5.63368L11.3882 9.63368C11.1279 9.89403 10.7058 9.89403 10.4454 9.63368C10.1851 9.37333 10.1851 8.95122 10.4454 8.69087L13.3074 5.82893H1.59068C1.21843 5.82893 0.916656 5.53045 0.916656 5.16226C0.916656 4.79407 1.21843 4.49559 1.59068 4.49559H13.3073L10.4454 1.63368Z" />
</svg>
</div>
</div>
</a>
</div>

</div>
</div>


<a name="stats"></a>
<div class="az">
</div>
<div class="ax">
</div>
<img class="aj" src="https://ods.pp.ua/wp-content/themes/jjj/img/c.png">


<div class="ba">
<div class="baz">
All-in-one platform for hospitals
</div>
<div class="bb">
Time is the most precious thing you have in running a hospital. You cannot take time to reflect on the productivity of a medical staff.
</div>
 <div class="bn">
 <a href="#contact">


 Get Started for Free
 </a>


</div>
</div>
<img class="ah" src="https://ods.pp.ua/wp-content/themes/jjj/img/mma.jpg">
<img class="ahh" src="https://ods.pp.ua/wp-content/themes/jjj/img/mmaa.png">
<img class="ahhh" src="https://ods.pp.ua/wp-content/themes/jjj/img/med.png">

<a name="how"></a>
<div class="ae">
Made in Germany
</div>
<div class="af">
</br>
Text iMedflow wird in Deutschland entwickelt – speziell für die Bedürfnisse von niedergelassenen Ärzten und entsprechend der Anforderungen der DSGVO.
iMedflow wird in Deutschland entwickelt – speziell für die Bedürfnisse von niedergelassenen Ärzten und entsprechend der Anforderungen der DSGVO.
</div>
<img class="afi"src="https://ods.pp.ua/wp-content/themes/jjj/img/mmm.jpg">
<div class="bttn">
<img src="https://ods.pp.ua/wp-content/themes/jjj/img/bt1.png">
<img src="https://ods.pp.ua/wp-content/themes/jjj/img/bt2.png">
</div>
<a name="try"></a>
<div class="ae">
Mobile App for patients
</div>
<div class="af">
</br>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et tristique placerat donec sodales dictum gravida fermentum faucibus. Id quis quam tincidunt hendrerit enim eget elit. Phasellus in varius proin aliquet ac turpis amet. Hendrerit nisi, turpis mi viverra. Lectus ultrices ipsum quis nunc, enim consequat. 

Pellentesque porttitor pellentesque auctor sit fames tempor, netus. Faucibus praesent nulla vel nulla. Sit ornare scelerisque viverra at dolor, ac, at diam gravida. Aliquam arcu velit netus odio sapien vel, mattis. 
</div>


<img class="aj" src="https://ods.pp.ua/wp-content/themes/jjj/img/mmf.jpg">
<a name="contact"></a>
<div class="fl">
<div class="page7"></div>

<div id="flz" class="flz">
Let’s Get in Touch!
</div>
<div id="flt" class="flt">
For the purposes of subsequent cooperation, your details are required.
</div>
     <form>
  <p>Name<br>
  <div id="nam">
   <input class="inp" id="name" placeholder="Please enter your name and surname" type="text" size="40">
   </div> 
  </p>
    <p id="pn">Phone number<br>
    <div id="num" class="num">
   <input class="inp" id="number" placeholder="Please enter your phone number" type="text" size="40">
</div> 
  </p>

  <p>E-mail<br>
   <div id="ema">
   <input class="inp" id="mail" placeholder="Please enter email address" type="text" size="40">
   </div>
  </p>
   <div onclick="check()" class="agry" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/empty.svg">
   <div id="check" style="background-image:url(<?php echo get_template_directory_uri(); ?>/img/full.svg)"></div>
   </div>
<p id="checkb">I agree to the processing of my data</p>

<a href="#contact">
  <div id="aply" class="aply">
Apply for Demo
</div>
</a>

 </form>  
    </div>
    </div>
  <div class="ff">
   </div>