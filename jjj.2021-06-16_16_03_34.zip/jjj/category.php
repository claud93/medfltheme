
<?php
/**
 * Главная страница (index.php)
 * @package WordPress
 * @subpackage your-clean-template-3
 */



include "header-mobile.php";
include "index-mobile.php";
include "footer-mobile.php";



 ?>