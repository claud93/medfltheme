document.addEventListener('touchstart', handleTouchStart, false);  
document.addEventListener('touchmove', handleTouchMove, false);
var xDown = null;                                                        
var yDown = null; 
var fea = document.getElementById("feai");
var lev = 0;
function handleTouchStart(evt) {                                         
    xDown = evt.touches[0].clientX;                                      
    yDown = evt.touches[0].clientY;                                      
};                                                

function handleTouchMove(evt) {
    if ( ! xDown || ! yDown ) {
        return;
    }

    var xUp = evt.touches[0].clientX;                                    
    var yUp = evt.touches[0].clientY;

    var xDiff = xDown - xUp;
    var yDiff = yDown - yUp;
 
    if ( Math.abs( xDiff ) > Math.abs( yDiff ) ) {
        if ( xDiff < 0 & lev < 0) {
            lev++
         fea.style.marginLeft = 300*lev+"px";
        } 
        else if (xDiff > 0 & lev > -5){
        lev--
         fea.style.marginLeft = 300*lev+"px";
         if(lev == -5){
         fea.style.marginLeft = 285*lev+"px";
         lev--
         }
        

        }   
                 else if (xDiff > 0 & lev == -6){
         lev = 0;
         fea.style.marginLeft = "0px";
        }
    }
    xDown = null;
    yDown = null;                                             
};