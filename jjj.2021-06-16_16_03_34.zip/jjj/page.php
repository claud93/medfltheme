
<?php
/**
 * Главная страница (index.php)
 * @package WordPress
 * @subpackage your-clean-template-3
 */
get_header(); // подключаем header.php ?> 


<div class="wr" style="
    padding-top: 72px;
">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                 
  <div class="title"><?php the_title(); ?></div>
                <div class="content"> <?php the_content(); ?></div>

            <?php endwhile; endif; ?>
            </div>

<?php get_footer(); // подключаем footer.php ?>