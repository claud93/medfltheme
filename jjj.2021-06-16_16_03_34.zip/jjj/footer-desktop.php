    <div class="s7">
    <div class="wr df">
    <div class="fc1">
<a href="/">
<img src="<?php echo get_template_directory_uri(); ?>/img/l2.png"/>
</a>
<div id="fo1" class="fcr1">
    Your ulitmate optimization solution to improve quality and productivity of medical staff and have better communications with future patients.
 </div>

 <div id="fo2"  onclick="qu()" class="fcr2">
Have any questions?
 </div>

    </div>
        <div class="fc2">
 <div id="fo3" class="fcr3">
Community
 </div>
  <div class="fcr4">
 <a href="#home"><p>Home</p></a>
 <a href="#about"><p id="fo4">About</p></a>
 <a href="#features"><p>Features</p></a>
 <a href="/datenschutzerklarung"> <p class="<?php 
global $post;

if( $post->ID == 476) { 

echo "copi";

 } ?>">Datenschutzerklärung</p></a>
 <a  href="/impressum"> <p class="<?php 
global $post;

if( $post->ID == 478) { 

echo "copi";

 } ?>">impressum</p></a>
 </div>

    </div>
      
        <div class="fc2">
 <div class="fcr3">
Contacts
 </div>
  <div class="fcr5">
 <p id="fo5" >Feel free to get in touch with us</br> via phone or send us a message.</p>
</br> <p>+49 (0)30 548 928 53</br></p>
<p style="text-decoration: underline;">medfluxinfo@gmail.com</p>
 </div>

    </div>
    </div>
    
    
    
    <div class="wr ff">
    </div>
    <div class="cop wr">
    © iMedflow 2020, All Rights Reserved
    </div>
    </div>
    </div>
    
    
     <div id="pop" class="pop" onclick="quq()" >
     <div class="cl" onclick="quq()" style="background-image: url(<?php echo get_template_directory_uri(); ?>/img/close.png">>
 </div>
 </div>
      <div id="popo" class="popo" >
     <div class="wr popout">
    <form>
     <div class="popin" style="background-image: url(<?php echo get_template_directory_uri(); ?>/img/pop.png">
      <div id="pop1" class="haq">
     Have any questions?
     </div>
      <div id="pop2" class="haqz">
     Send us your message and we will try to answer as fast as possible.
     </div>
     <div class="popf">
     <p>E-mail<br>
<div id="ema2">
   <input class="inp" id="mail" placeholder="Please enter email address" type="text" size="40">
   </div>
   </p>
  <p id="pop4"> Message<br>
  <div id="pop5">
   <textarea class="inp" id="mess" placeholder="Your Message" type="comment" cols="40" rows="3"></textarea>
   </div>
  </p>
  <div class="aply">

Send
</div>
 </div>
 </div>
   </form>
 </div>
 </div>
    
    
    
    

    
    
    
    
    
    
    
    
    
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scroll.js"></script>
<script>


jQuery(function($){


$('.aply').click(function(){
var name = document.getElementById('name').value;
var number = document.getElementById('number').value;
var mail = document.getElementById('mail').value;
$.ajax({
type:"post",


url:'/wp-admin/admin-ajax.php',
data:{
action:'aply',
name,
number,
mail,
},

success:function(data){
alert('отправленно '+ name + number + mail);
alert('полученно из бази' + data);

}

});
});
});
</script>

<style>
#t1 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/tar.png);
    height:163px;
    width: 163px;
}
#t2 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/j.png);
}
#f1 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/1.png);
}
#f2 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/2.png);
}
#f3 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/3.png);
}
#f4 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/4.png);
}
#f5 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/5.png);
}
#f6 {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/6.png);
}
.ger {
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/germany.png);
    }
    #check{
    background:url(<?php echo get_template_directory_uri(); ?>/img/ci.png)
}

.menu-item:hover {
background-image: url(<?php echo get_template_directory_uri(); ?>/img/p.png);
}
.menu-item-current {
background-image: url(<?php echo get_template_directory_uri(); ?>/img/p.png);
}

.copi {
    padding: 0 0 0 15px;
    color: #F2C94C;
    background-repeat: no-repeat;
    background-position-y: center;
    background-image: url(<?php echo get_template_directory_uri(); ?>/img/p.png);

}




</style>