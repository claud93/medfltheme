<?php

 	wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/style-desktop.css' );

?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>


<div style="background-image:url(https://ods.pp.ua/wp-content/themes/jjj/img/te.jpg);position: absolute;width: 100%;height: 0px;background-position-x: center;background-repeat: no-repeat;z-index: 99999;"></div>

<a name="home"></a>
<a id="c1"></a>
<div class="menti">
<div class="wr wrm hd">
<div class="page1"></div>
<a href="/">
<img style="float:left" src="<?php echo get_template_directory_uri(); ?>/img/l.png"/>
</a>
<div class="me">


<?php wp_nav_menu(); ?>

</div>
<a href="#contact">
<div id="ti" class="ti">Try it now</div>
</a>
<div class="lang">
<a id="en" onclick="en()" style="font-family: 'Manropeb';color:black">EN</a>
<a id="de" onclick="de()" style="font-family: 'Manrope';color:grey" >DE</a>
</div>
</div>
</div>